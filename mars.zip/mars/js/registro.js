document.getElementById('registroForm').addEventListener('submit', function(e) {
  const nombre = this.nombre.value.trim();
  const edad = this.edad.value.trim();
  const email = this.email.value.trim();
  const usuario = this.usuario.value.trim();
  const password = this.password.value.trim();

  if (!nombre || !edad || !email || !usuario || !password) {
    e.preventDefault();
    alert('Por favor, completa todos los campos.');
  }
});
