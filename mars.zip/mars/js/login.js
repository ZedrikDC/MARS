document.getElementById('loginForm').addEventListener('submit', function(e) {
  const email = this.email.value.trim();
  const password = this.password.value.trim();

  if (!email || !password) {
    e.preventDefault();
    alert('Por favor, completa todos los campos.');
  }
});
