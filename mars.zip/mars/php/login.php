<?php
session_start();
require 'conexion.php';

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if ($email && $password) {
  $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE email = ?');
  $stmt->execute([$email]);
  $usuario = $stmt->fetch();

  if ($usuario && password_verify($password, $usuario['password'])) {
    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['rol'] = $usuario['rol'];
    header('Location: ../index.html');
    exit;
  } else {
    echo 'Credenciales incorrectas.';
  }
} else {
  echo 'Por favor, completa todos los campos.';
}
?>
