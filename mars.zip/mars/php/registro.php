<?php
require 'conexion.php';

$nombre = $_POST['nombre'] ?? '';
$edad = $_POST['edad'] ?? '';
$email = $_POST['email'] ?? '';
$usuario = $_POST['usuario'] ?? '';
$password = $_POST['password'] ?? '';

if ($nombre && $edad && $email && $usuario && $password) {
  $hash = password_hash($password, PASSWORD_DEFAULT);
  $stmt = $pdo->prepare('INSERT INTO usuarios (nombre, edad, email, usuario, password) VALUES (?, ?, ?, ?, ?)');
  $stmt->execute([$nombre, $edad, $email, $usuario, $hash]);
  header('Location: ../login.html');
  exit;
} else {
  echo 'Por favor, completa todos los campos.';
}
?>
