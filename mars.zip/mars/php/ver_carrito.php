<?php
session_start();
require '../php/conexion.php';

if (!isset($_SESSION['usuario_id'])) {
  header('Location: ../login.html');
  exit;
}

$usuario_id = $_SESSION['usuario_id'];

$stmt = $pdo->prepare('
  SELECT c.id, p.nombre, p.precio, p.imagen, c.cantidad
  FROM carrito c
  JOIN productos p ON c.producto_id = p.id
  WHERE c.usuario_id = ?
');
$stmt->execute([$usuario_id]);
$items = $stmt->fetchAll();

$total = 0;
foreach ($items as $item) {
  $total += $item['precio'] * $item['cantidad'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Carrito de Compras</title>
  <link rel="stylesheet" href="../estilos.css">
</head>
<body>
  <div class="container">
    <h2>Tu Carrito</h2>
    <?php if ($items): ?>
      <table>
        <tr>

::contentReference[oaicite:0]{index=0}
 

