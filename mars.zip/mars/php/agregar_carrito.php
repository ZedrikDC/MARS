<?php
session_start();
require 'conexion.php';

$data = json_decode(file_get_contents("php://input"), true);
$id_producto = $data['id_producto'];
$id_usuario = $_SESSION['id_usuario'];

// Verificar si el producto ya está en el carrito
$sql = "SELECT cantidad FROM carrito WHERE id_usuario = ? AND id_producto = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id_usuario, $id_producto);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Si existe, incrementar la cantidad
    $fila = $result->fetch_assoc();
    $nueva_cantidad = $fila['cantidad'] + 1;
    $sql = "UPDATE carrito SET cantidad = ? WHERE id_usuario = ? AND id_producto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $nueva_cantidad, $id_usuario, $id_producto);
    $stmt->execute();
} else {
    // Si no existe, insertar nuevo registro
    $sql = "INSERT INTO carrito (id_usuario, id_producto, cantidad) VALUES (?, ?, 1)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_usuario, $id_producto);
    $stmt->execute();
}

echo "Producto agregado al carrito.";
?>
