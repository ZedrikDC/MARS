<?php
require 'conexion.php';

$nombre = isset($_GET['nombre']) ? $_GET['nombre'] : '';
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$por_pagina = 6;
$inicio = ($pagina - 1) * $por_pagina;

$sql = "SELECT * FROM productos WHERE activo = 1 AND nombre LIKE ? LIMIT ?, ?";
$stmt = $conn->prepare($sql);
$param_nombre = "%$nombre%";
$stmt->bind_param("sii", $param_nombre, $inicio, $por_pagina);
$stmt->execute();
$resultado = $stmt->get_result();

$productos = [];
while ($fila = $resultado->fetch_assoc()) {
    $productos[] = $fila;
}

echo json_encode($productos);
?>
