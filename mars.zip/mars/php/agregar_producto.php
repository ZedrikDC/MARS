<?php
require 'conexion.php';

$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];
$precio = $_POST['precio'];
$cantidad = $_POST['cantidad'];
$imagen = $_FILES['imagen']['name'];
$imagen_tmp = $_FILES['imagen']['tmp_name'];
$ruta_imagen = "../uploads/" . $imagen;

move_uploaded_file($imagen_tmp, $ruta_imagen);

$sql = "INSERT INTO productos (nombre, descripcion, precio, cantidad, imagen, activo) VALUES (?, ?, ?, ?, ?, 1)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssdiss", $nombre, $descripcion, $precio, $cantidad, $imagen);
$stmt->execute();

echo "Producto agregado exitosamente.";
?>
