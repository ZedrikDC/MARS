<?php
session_start();
require 'conexion.php';

$data = json_decode(file_get_contents("php://input"), true);
$id_producto = $data['id_producto'];
$id_usuario = $_SESSION['id_usuario'];

$sql = "DELETE FROM carrito WHERE id_usuario = ? AND id_producto = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id_usuario, $id_producto);
$stmt->execute();

echo "Producto eliminado del carrito.";
?>
