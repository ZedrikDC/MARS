<?php
session_start();
require 'conexion.php';

$id_usuario = $_SESSION['id_usuario'];

// Obtener productos del carrito
$sql = "SELECT c.id_producto, c.cantidad, p.cantidad AS stock FROM carrito c JOIN productos p ON c.id_producto = p.id WHERE c.id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

$productos = [];
while ($fila = $result->fetch_assoc()) {
    if ($fila['cantidad'] > $fila['stock']) {
        echo "No hay suficiente stock para el producto ID: " . $fila['id_producto'];
        exit;
    }
    $productos[] = $fila;
}

// Procesar compra
foreach ($productos as $producto) {
    $nuevo_stock = $producto['stock'] - $producto['cantidad'];
    $sql = "UPDATE productos SET cantidad = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $nuevo_stock, $producto['id_producto']);
    $stmt->execute();
}

// Limpiar carrito
$sql = "DELETE FROM carrito WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();

echo "Compra procesada exitosamente.";
?>

